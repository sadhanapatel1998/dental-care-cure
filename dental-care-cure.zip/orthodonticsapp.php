﻿<?php
// ---- Page settings ----
// Ye app-view page hai (bina header/footer ke), isliye includes use nahi kiye
$pageCanon = "https://dentalcarencure.com/orthodonticsapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
<link rel="canonical" href="<?= $pageCanon ?>"/>


<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container-fluid no-padding department-section">  <div class="we-are-best col-md-12 col-sm-12 no-padding">
    <div class="we-are-best-block">
      <div>
        <h3>What is orthodontics  ?</h3>
        <strong style="font-size:18px;"> High Quality Cost Effective Treatment </strong>
        <p>Orthodontics is a specialized branch of dentistry that deals with the diagnosis, preventions and 
          
          corrections of dental and facial irregularities occurring as a result of, </p>
        <ol>
          <li> A bad bite. </li>
          <li> Missing of Extra Teeth. </li>
          <li> Misaligned teeth. </li>
          <li> Crowed teeth. </li>
          <li> An Overbite. </li>
        </ol>
        <p> <strong>At what age can one start orthodontic treatment?</strong><br>
        </p>
        <h3>Early Childhood – </h3>
        <p>You can have an orthodontic screening from the age of 7, by which time enough of the permanent teeth would have emerged, helping to identify potential problems. 
          Do not wait for the all the permanent teeth to erupt in the mouth, as the earlier you start the more the advantages.</p>
        <h3>During Adolescent and Teenage years-</h3>
        <p>All permanent teeth would have come in by now and treatment is most effective at this age.</p>
        <h3>At Adulthood – </h3>
        <p>Healthy teeth can be moved at any age. orthodontic treatment can help create and restore good function. Teeth that work better usually look better, too. A healthy, beautiful smile can improve self-esteem, no matter what your age.
          
          
          Ceramic braces are made of composite materials. Ceramic braces utilize less noticeable patients concerned about the appearance of their smile. Ceramic braces are translucent, so they blend in with your natural tooth color. This means that unlike traditional stainless metal braces, ceramic braces won’t make your smile look "metallic." In addition, ceramic braces are designed so that they won’t stain or discolor over long periods of time. </p>
      </div>
    </div>
  </div>
</div>
</body>
</html>