﻿<?php
// ---- Page settings ----
// Ye app-view page hai (bina header/footer ke), isliye includes use nahi kiye
$pageCanon = "https://dentalcarencure.com/oral-surgeryapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
<link rel="canonical" href="<?= $pageCanon ?>"/>

<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container no-padding department-section">  <div class="we-are-best col-md-12 col-sm-12 no-padding">
    <div class="we-are-best-block">
      <div>
        <h3 class="fontadj">Oral Surgery</h3>
        <p>Oral and maxillofacial surgery is a branch of dentistry that deals with the art of diagnosis and treatment of various diseases, pathologies and defects involving the orofacial region </p>
        <p> <strong>Oral and maxillofacial surgery essentially deals with the treatment of the following conditions:</strong><br>
        </p>
        <ol style="padding-left:10px; width:70%;">
          <li>Simple and complicated cysts and tumours of both odontogenic and nonodontogenic origin, involving the jaw bones.</li>
          <li> Fractures of the facial bones. </li>
          <li>Temporomandibular joint disorders including internal derangement and ankylosis. </li>
          <li> Salivary gland diseases. </li>
          <li> Dentofacial deformities, either acquired or congenital. </li>
          <li> Orofacial infections involving the soft and hard tissues. </li>
          <li> Precancerous conditions and lesions like, oral submucous fibrosis and leukoplakia. </li>
          <li> Detection and management of oral cancer. </li>
        </ol>
        <img src="images/wisdom.jpg" class="imgbdr" alt="Oral Surgery in Pachim Vihar" title="Oral Surgery in Pachim Vihar" style="float:right; width:300px; margin-top:-190px; margin-right: 40px;">
        <p style="padding-left:10px; width:60%;"> "Wisdom teeth" are a type of molar. Molars are the large chewing teeth found furthest in the back of the mouth.<br>
          Most people have 1st, 2nd and 3rd molars. A person's third molars are their wisdom teeth. For most people, the eruption process takes place during their late teens or early twenties (usually ages 18 to 24 years), although eruption outside of this age range is not uncommon. <br>
          If there is not enough room for the teeth, or they are not aligned properly, they may never fully erupt.<br>
          <br>
          <strong>This failure to erupt properly might occur because:</strong><br>
          <br>
        </p>
        <ul style="padding-left:10px">
          <li>There is not enough room in the person's jaw to accommodate the tooth.</li>
          <li>The tooth's eruption path is obstructed by other teeth.</li>
          <li>Because the angulation of the tooth is improper.</li>
        </ul>
        <br>
        Wisdom teeth under ideal circumstances should grow in straight like any other tooth. However it is common for wisdom teeth to become<br>
        impacted inside the jaw or just under the gums. If this occurs, your wisdom teeth should be removed. Common Impactions:<br>
        <ol>
          <li>Horizontal Impaction </li>
          <li> Angular Impaction </li>
          <li> Vertical Impaction </li>
          <li> Soft Tissue Impaction</li>
        </ol>
      </div>
    </div>
  </div>
</div>
</body>
</html>