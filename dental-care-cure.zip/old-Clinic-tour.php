﻿<!DOCTYPE html>
<html lang="en" class="">


<head>
	<meta charset="utf-8">
		<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<meta name="description" content="Discover how TMJ disorder headaches and migraines are linked, symptoms, causes & treatment options. Expert insights from Dental Care 'N' Cure.">
		<meta name="keywords" content="TMJ disorder headaches and migraines">
		<!-- <meta name="googlebot" content="noodp" /> -->
		<meta name="robots" content="index, follow" />
		<!-- <meta name="robots" content="noodp" /> -->
		<meta name="distribution" content="Global" />
		<meta name="language" content="EN-US" />
		<meta name="classification" content="Helthcare" />
		<meta name="author" content="Dental Healthcare India " />
		<link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
		<title>TMJ Disorder Headaches and Migraines: Symptoms, Causes & Treatment</title>

<script type="application/ld+json">
	{
	  "@context": "https://schema.org",
	  "@type": "MedicalOrganization",
	  "name": "Dental Care 'N' Cure",
	  "url": "https://dentalcarencure.com/",
	  "logo": "https://dentalcarencure.com/images/logo-banner.png",
	  "sameAs": [
		"https://www.facebook.com/DentalCarenCure/",
		"https://x.com/DentalCareNCure",
		"https://www.instagram.com/dentalcarencure/",
		"https://www.youtube.com/channel/UCIlqkg_bkS8_949GqFP74Xw"
	  ]
	}
	</script>

<link rel="canonical" href="https://dentalcarencure.com/can-tmj-disorder-cause-headaches-and-migraines.php"/>
	<!-- Standard Favicon -->
	<link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
	
	<!-- For iPhone 4 Retina display: -->
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">
	
	<!-- For iPad: -->
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">
	
	<!-- For iPhone: -->
	<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">	
	
	<!-- Library - Loader CSS -->
	<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

	<!-- Library - Google Font Familys -->

	<!-- Library - Bootstrap v3.3.5 -->
    <link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">
	
	<!-- Font Icons -->
	<link rel="stylesheet" type="text/css" href="libraries/fonts/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

	<!-- Library - OWL Carousel V.2.0 beta -->
	<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

	<!-- Library - Animate CSS -->
	<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

	<!-- Library - Magnific Popup -->
	<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

	<!-- Custom - Common CSS -->
	<link rel="stylesheet" type="text/css" href="css/plugins.css">
	<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">

	<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->
	
	<!-- Custom - Theme CSS -->
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/shortcodes.css">

	<!-- Page-specific CSS -->
	<style type="text/css">
		li.blogul {
			margin-bottom: 20px;
		}

		body {
			background: #f8fbff !important;
		}
	</style>

	<!--[if lt IE 9]>
<script src="js/html5/respond.min.js"></script>    <![endif]-->
<!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-117860537-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-117860537-1');
    </script>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-6B0PZFEN30"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'G-6B0PZFEN30');
    </script>
    <!-- Google Tag Manager -->
    <script>        (function (w, d, s, l, i) {
            w[l] = w[l] || []; w[l].push({ 'gtm.start':
new Date().getTime(), event: 'gtm.js'
            }); var f = d.getElementsByTagName(s)[0],
j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WXFMHMFJ');</script>
    <!-- End Google Tag Manager -->

<script>

<practo:abs_widget widget="e0b38d457e7af9c3" class="onli_link"></practo:abs_widget><script src="https://www.practo.com/bundles/practopractoapp/js/abs_widget_helper.js"></script>
		

</head><body data-offset="200" data-spy="scroll" data-target=".ow-navigation">
	<!-- Loader -->
	<!-- Loader /- -->
	
	<a id="top"></a>
	<!-- Main Container -->
	<div class="main-container">
		<!-- Header -->
		<header class="header-main">
			<!-- Top Header -->
			<div class="top-header container-fluid no-padding">
				<!-- Container -->
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<p>We take care of your smiles</p>
						</div>
						<div class="col-md-6 text-right">
							<ul>
								<li><a href="https://www.facebook.com/DentalCarenCure/" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>	
								<li><a href="https://twitter.com/DentalCareNCure" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://www.instagram.com/dentalcarencure/" target="_blank" title="Instagram"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCIlqkg_bkS8_949GqFP74Xw" target="_blank"  title="youtube"><i class="fa fa-youtube"></i></a></li>
							</ul>
							
						</div>
					</div>
				</div><!-- container /- -->
			</div><!-- Top Header /- -->
			<!-- Logo Block -->
			<div class="middle-header container-fluid no-padding">
				<!-- Container -->
				<div class="container">
					<div class="row">
						<div class="col-md-3 logo-block pull-left">
							<a href="index.html" title="Logo"><img src="images/logo.png" class="phlogo" alt="Logo" style="width: 180px;
    margin-top: 5px;" /></a>
						</div>
						<div class="col-md-9"><div class="location">
								<h3><img src="images/location-ic.png" alt="Location" /> Our Location</h3>
								<p>1st Floor, D2, Shubham Enclave, Paschim Vihar, New Delhi - 110063</p>
							</div>
							<div class="phone">
								<h3><img src="images/phone-ic.png" alt="phone" />+91- 9310999214</h3>
								<p>Call for free consultation</p>
							</div>
						</div>
					</div>
				</div><!-- Container -->
			</div><!-- Logo Block /- -->
			<!-- Navigation -->
			<nav class="navbar ow-navigation">
				<div class="container">
					<div class="row">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div id="navbar" class="navbar-collapse collapse">
							<ul class="nav navbar-nav">
								<li ><a href="index.html">Home</a></li>
								<li><a href="aboutus.html">About Us</a></li>
								<li  class="dropdown"><a class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false" href="services.html">Services</a>
                                
                                
                                <i class="ddl-switch fa fa-angle-down"></i>
									<ul class="dropdown-menu">
										<li>
													<a href="cosmetic-dentistry.html">Cosmetic Dentistry</a>
												</li>

												<li>
													<a href="dental-crowns.html">Dental Crowns and Tooth Bridges</a>
												</li>
												<li>
													<a href="dental-implant.html">Dental Implants</a>
												</li>
												<li>
													<a href="oral-surgery.html">Oral Surgery</a>
												</li>
                                                
                                                
                                                <li>
													<a href="orthodontics.html">Orthodontics</a>
												</li>

												<li>
													<a href="root-canal.html">Root Canals</a>
												</li>
												<li>
													<a href="smile-design.html">Smile Design</a>
												</li>
												<li>
													<a href="teeth-whitening.html">Teeth Whitening</a>
												</li>

									</ul>
                                </li>
													
								<li><a href="smile-gallery.html">Smile Gallery </a></li>
                                 <li><a href="Clinic-tour.html">Clinic Tour</a></li>
                                <li><a href="dental-implant.html">Dental Implants</a></li>
								
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">Dental Tourism</a>
									<i class="ddl-switch fa fa-angle-down"></i>
									<ul class="dropdown-menu">
										<li>
													<a href="dental-tour.html">Dental Tourism</a>
												</li>

												<li>
													<a href="http://dentalcarencure.com/dental-care-india/" target="_blank">Cost Benefit</a>
												</li>
												<li>
													<a href="tourist-destinations.html">Tourist Destinations</a>
												</li>
												<li>
													<a href="packing-tips.html">Packing Tips</a>
												</li>

									</ul>
								</li>
								<li><a href="contact-us.html">Contact</a></li>
							</ul>						
						</div>
					</div>
				</div>
			</nav>
		</header>

		<!-- Page Banner -->
		<div class="page-banner blog-banner container-fluid no-padding">
			<!-- Container -->
			<div class="container">
				<h2 class="topheading_spacing">Can TMJ Disorder Cause Headaches and Migraines</h2>
			</div><!-- Container /- -->
			<!-- Shape -->
			<div class="banner-shape container-fluid no-padding">
				<div class="col-md-6 col-sm-6 col-xs-6 shape-left no-padding">
					<div class="left-shape-blue">				
						<svg width="100%" height="100%">
							<clipPath id="clipPolygon2" clipPathUnits="objectBoundingBox">
								<polygon points="0 0, 0 100, 120 100, 0 0"></polygon>
							</clipPath>
						</svg>
					</div>	
					<div class="left-shape">				
						<svg width="100%" height="100%">
							<clipPath id="clipPolygon1" clipPathUnits="objectBoundingBox">
								<polygon points="0 0, 0 100, 100 100, 0 0"></polygon>
							</clipPath>
						</svg>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-6 shape-right no-padding">
					<div class="right-shape-blue">				
						<svg width="100%" height="100%">
							<clipPath id="clipPolygon3" clipPathUnits="objectBoundingBox">
								<polygon points="1 0.2, 0 1, 0 0.835, 1 0"></polygon>
							</clipPath>
						</svg>
					</div>	
					<div class="right-shape">				
						<svg width="100%" height="100%">
							<clipPath id="clipPolygon4" clipPathUnits="objectBoundingBox">
								<polygon points="1 0, 0 1, 100 100, 100 0"></polygon>
							</clipPath>
						</svg>
					</div>
				</div>
			</div><!-- Shape -->
		</div><!-- Page Banner /- -->
		
		<!-- Departments Section -->
		<div class="container blog-section py-5">
			<div class="row">

				<!-- LEFT BLOG CONTENT -->
				<div class="col-lg-10">

					<!-- Featured Image -->
					<div class="mb-4 ">
						<img src="images/tmj-disorder-headaches-migraines-dental-care-n-cure.jpg.jpeg"
							class="img-fluid rounded shadow-sm" alt="TMJ disorder causing headaches and migraines with jaw joint pain illustration"
							style="border:1px ; border-radius:15px; padding:3px;">
					</div>

					<h1 class="mb-3">Can TMJ Disorder Cause Headaches and Migraines? Symptoms, Causes & Treatment
						Explained</h1>

					<p>
						TMJ disorder, headaches and migraines are more connected than most people realize. Many patients
						keep treating headaches for years without knowing the real root cause is in the jaw
						joint.<strong> At Dental Care 'N' Cure, </strong>we often see patients walking in suffering from
						chronic headaches, only to discover that the real issue is related to the <strong>
							temporomandibular joint disorder (TMJ).</strong>


						If you are someone who keeps Googling why does my head feel like it is under pressure? or you
						are <strong> dealing with migraine pain </strong>without clear relief, your jaw might be the
						hidden culprit.


						Patients visiting a <a
							href="https://dentalcarencure.com/tmj-disorder-treatment-in-paschim-vihar.html">TMJ pain
							specialist in Paschim Vihar</a> often report symptoms like jaw stiffness, ear pain, and
						facial discomfort. In many cases, they never connect these issues to headaches until diagnosis.
						This is where a proper dental and neuromuscular evaluation becomes important.

						Let’s break it down in a simple, human way, no jargon overload, just clarity with facts.
					</p>

					<h2 class="mt-4">Understanding TMJ Disorder and Its Link to Headaches
					</h2>

					<p>
						The <strong>temporomandibular joint (TMJ)</strong> connects your jaw to your skull and acts like
						a sliding hinge. When this system stops working smoothly, it leads to jaw joint dysfunction,
						headaches and even migraines.

						In medical terms, TMJ disorder falls under craniofacial pain and orofacial pain conditions. It
						involves surrounding structures like the masseter muscle, temporalis muscle, and sometimes even
						the trigeminal nerve, which directly influences headache pathways.

					</p>

					<h3 class="mt-4">
						At Dental Care 'N' Cure, we see that TMJ issues often overlap with:

					</h3>

					<ul>
						<li>Bruxism (teeth grinding)
						</li>
						<li>Bite misalignment or <strong> dental occlusion issues</strong>
						</li>
						<li>Stress-related jaw clenching
						</li>
						<li>Muscle tension in the jaw and neck
						</li>
					</ul>

					<p>
						This is why TMJ disorder headaches and migraines are not just headaches. They are often
						biomechanical and muscular in origin.

						Patients visiting a TMJ pain specialist frequently report that their headaches worsen during
						stress, chewing, or even speaking for long periods.

					</p>

					<h2>Symptoms You Should Not Ignore</h2>

					<p>
						Many people ignore early signs of <strong> temporomandibular joint disorder symptoms,</strong>
						thinking it is just stress. But the body keeps sending signals.

					</p>

					<h3>Common Symptoms</h3>

					<ul>
						<li>Experiencing jaw pain while chewing or talking</li>
						<li>Clicking or popping sounds in the jaw joint</li>
						<li>Feeling pressure in the head or temples</li>
						<li>Ear pain and the connection to TMJ disorder</li>
						<li>Feeling tension in the jaw muscles and neck</li>
						<li>Unable to open the mouth properly in severe cases</li>
						<li>Frequent migraine triggers include jaw misalignment episodes</li>
						<li>Feeling constant head tightness after waking up</li>
					</ul>

					<p>
						Some patients even describe it humorously at <strong> Dental Care 'N' Cure</strong> like: My jaw
						clicks louder than my phone notifications.
					</p>
					<p>But jokes aside, these signs often indicate deeper facial pain and TMJ disorder issues that
						require attention.

					</p>

					<h2 class="mt-4">Causes of TMJ Disorder and Headaches

					</h2>

					<p>
						There is no single cause of TMJ disorder. Instead, multiple triggers work together.

					</p>

					<ul>
						<li><strong>Teeth Grinding (Bruxism):</strong> Bruxism, teeth grinding, and headaches are among the biggest contributors. Many patients grind their teeth unknowingly during sleep, putting pressure on jaw muscles.</li>
						<li><strong>Stress and Muscle Tension:</strong> Stress causes muscle tension in the jaw and neck, leading to inflammation and pain that radiates into the head.</li>
						<li><strong>Bite Problems:</strong> Misaligned bite or bite misalignment leads to uneven pressure in the jaw joint, worsening headaches.</li>
						<li><strong>Joint Dysfunction:</strong> When the mandibular joint doesn’t function properly, it creates inflammation in the surrounding tissues.</li>
						<li><strong>Poor Posture:</strong> Long screen time also contributes to chronic tension headache causes, especially when the head posture is forward.</li>
					</ul>

					<p>
						At our clinic, we often combine dental evaluation with lifestyle analysis to identify the exact
						cause.

					</p>

					<p>
						Many patients initially visit a <a href="https://dentalcarencure.com/best-dental-clinic-in-delhi.html"> Best dental clinic in Delhi,</a>
						thinking it’s a tooth issue, but later discover TMJ involvement.

					</p>

					<h2 class="mt-4">TMJ and Headache Connection Explained Simply

					</h2>

					<p>Think of your jaw like a machine hinge. If it becomes misaligned, surrounding muscles overwork to
						compensate. This leads to:

					</p>

					<ul>
						<li>Trigger points in the <strong>temporalis muscle</strong></li>
						<li>Strain in the <strong>masseter muscle</strong></li>
						<li>Irritation of the <strong>trigeminal nerve</strong></li>
					</ul>

					<p>This chain reaction results in <strong>TMJ pain and headache connection,</strong> often mistaken
						for migraines.
					</p>

					<h3 class="mt-4">Patients often report:</h3>

					<ul>
						<li><strong>Worsening headache symptoms</strong> in the morning</li>
						<li>Pain while chewing food <strong>(difficulty chewing food)</strong></li>
						<li><strong>Pain while speaking or chewing</strong></li>
						<li>Frequent <strong>migraine disorders flare-ups</strong></li>
					</ul>

					<p>
						This is why proper diagnosis is critical, as both dental and muscular causes are evaluated
						together.

					</p>

					<h2 class="mt-4">Diagnosis and Clinical Evaluation</h2>
					<p>At our clinic, we follow a structured diagnostic process:</p>

					<h3 class="mt-4">We Assess</h3>

					<ul>
						<li>Jaw movement patterns
						</li>
						<li>Bite alignment <strong>(dental occlusion)</strong>
						</li>
						<li>Muscle tenderness
						</li>
						<li>Joint sounds (clicking/popping)
						</li>
						<li>Signs of <strong>bruxism</strong>
						</li>
					</ul>

					<p>We may also refer to imaging if required, especially in severe <strong> headache
							disorder</strong> cases.</p>

					<p>
						This is part of a broader <strong>neuromuscular dentistry</strong> approach that connects dental
						health with
						muscle function and pain pathways.
						Patients often come after months of<strong> suffering from chronic headaches,</strong> only to
						realize the root
						cause was dental-joint related.

					</p>

					<h2 class="mt-4">Treatment Options for TMJ Disorder Headaches and Migraines

					</h2>

					<p>
						Treatment depends on severity and cause.

					</p>

					<ul>
						<li><strong>Lifestyle Changes:</strong> Reducing stress, improving posture, and avoiding hard chewing help reduce strain.</li>
						<li><strong>Dental Correction:</strong> Orthodontic adjustments or <strong>orthodontic treatment</strong> may be recommended in cases of bite issues.</li>
						<li><strong>Splints and Night Guards:</strong> These help control <strong> bruxism, teeth grinding, and headaches</strong> during sleep.</li>
						<li><strong>Physiotherapy:</strong> Referral to <strong>physiotherapy clinics</strong> helps relax jaw and neck muscles.</li>
						<li><strong>Advanced Dental Care:</strong> In complex cases, <strong>oral and maxillofacial surgery</strong> or <strong>dental sleep medicine</strong> approaches may be needed.</li>
					</ul>

					<p>At our clinic, we focus on non-invasive solutions first before considering advanced procedures.
					</p>

					<h2 class="mt-4">Why Early Treatment Matters</h2>
					<p><strong>
							Ignoring TMJ symptoms can lead to long-term complications like:

						</strong></p>
					<ul>
						<li>Chronic migraines</li>
						<li>Jaw locking</li>
						<li>Increased craniofacial pain</li>
						<li>Sleep disturbances</li>
					</ul>

					<p>
						Early treatment not only reduces pain but also improves quality of life significantly.

					</p>

					<p>
						Many patients who visit the <strong> Best dental clinic in Delhi</strong> report dramatic
						improvement once TMJ therapy begins.

					</p>

					<h2 class="mt-4">Final Thoughts on TMJ Pain and Headache Connection
					</h2>
					<p>TMJ disorder, headaches and migraines are closely linked, even if they feel like separate
						problems. If you are experiencing jaw pain, feeling pressure in your head, or dealing with
						migraine pain, the jaw joint might be the missing piece of the puzzle.

					</p>

					<p>
						At <a href="https://dentalcarencure.com/">Dental Care 'N' Cure,</a>  we believe in accurate diagnosis, patient-focused care, and long-term
						relief, not just temporary painkillers.
						If symptoms persist, consulting a<strong> TMJ pain specialist</strong> can help you identify the root cause early
						and prevent worsening conditions.
						Your jaw does a lot of work silently every day. It deserves attention before it starts
						complaining through headaches.
						<a href="https://dentalcarencure.com/contact-us.html">Contact Dental Care 'N' Cure</a> <strong>today to book your consultation </strong>and get expert evaluation for TMJ disorder, headaches and migraines. Early diagnosis and timely treatment can help restore comfort, reduce pain, and improve your overall quality of life.

					</p>

				</div>

				<!-- RIGHT SIDEBAR -->
				<div class="col-lg">

					<div class="card shadow-sm p-3">
						<h5>Book Consultation</h5>
						<p>Get expert Invisalign consultation in Paschim Vihar today.</p>
						<a href="contact-us.html" class="btn btn-primary w-100">Book Appointment</a>
					</div>

				</div>

			</div>
		</div><!-- Departments Section /- -->
	

		<!-- Footer -->
		<footer class="footer-main container-fluid no-padding">
			<!-- Container -->
			<div class="container">
				<!-- Contact Detail -->
				<div class="contact-details">
					<div class="col-md-4 col-sm-4 address-box detail-box">
						<i><img src="images/ftr-location.png" alt="Loactaion" /></i>
						<h4>Dental Care 'N' Cure </h4>
						<p>1st Floor, D2, Shubham Enclave,
</p>
						<p> 
Paschim Vihar, New Delhi- 110063  (India)</p>
					</div>
					<div class="col-md-4 col-sm-4 phone-box detail-box">
						<i><img src="images/ftr-phone.png" alt="Phone" /></i>
						<h4>Phone</h4>
						<p>Mobile: +91- 9310999214</p>
						<p>Landline : 011-47082337</p> 
					</div>
					<div class="col-md-4 col-sm-4 mail-box detail-box">
						<i><img src="images/ftr-email.png" alt="Email" /></i>
						<h4>Email:</h4>
						<p><a href="mailto:info@dentalcarencure.com">info@dentalcarencure.com </a></p>
						<p><a href="mailto:drmansiarora@gmail.com">drmansiarora@gmail.com </a></p>
					</div>
				</diV><!-- Contact Detail /- -->
				
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12">
						<aside class="widget widget-about">
							<h3><img src="images/logo.png" alt="Logo" width="150px" style="text-align:center;" /></h3>
							<p>The clinic is headed by Dr Mansi Arora Punia,  who is a prosthodontist and implantologist with more than 10 years of clinical experience. </p>
							<div class="time-schedule">
								<p>Monday - Saturday <span>10.00 am - 8.00pm</span></p>
								
								<p>Sunday <span>Closed</span></p>
							</div>
						</aside>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<aside class="widget widget-links">
							<h3 class="widget-title">Our Services</h3>
							<ul>
								<li><a href="cosmetic-dentistry.html" title=" Cosmetic Dentistry"> Cosmetic Dentistry</a></li>
								<li><a href="dental-crowns.html" title="Dental Crowns and Tooth Bridges"> Dental Crowns & Tooth Bridges </a></li>
								<li><a href="dental-implant.html" title="Dental Implants">Dental Implants</a></li>
								<li><a href="oral-surgery.html" title="Oral Surgery">Oral Surgery</a></li>
								<li><a href="orthodontics.html" title="Orthodontics">Orthodontics</a></li>
								<li><a href="root-canal.html" title="Root Canals">Root Canals</a></li>
								<li><a href="smile-design.html" title="Smile Design">Smile Design</a></li>
								<li><a href="teeth-whitening.html">Teeth Whitening</a></li>
								
							</ul>
						</aside>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<aside class="widget widget-newsletter">
							<h3 class="widget-title">Newsletter</h3>
							
							<div class="input-group">
								<input type="text" class="form-control" placeholder="Email Address">
								<span class="input-group-btn">
									<button class="btn btn-default" type="button"><i class="fa fa-send-o"></i></button>
								</span>
							</div><!-- /input-group -->
							<div class="social">
								<h6>Stay Connected</h6>
								<ul>
								<li><a href="https://www.facebook.com/DentalCarenCure/" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>	
								<li><a href="https://twitter.com/DentalCareNCure" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://plus.google.com/+DentalCarenCure" target="_blank" title="Google+"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="https://www.linkedin.com/in/dentalcarencure" target="_blank"  title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCIlqkg_bkS8_949GqFP74Xw" target="_blank"  title="Linkedin"><i class="fa fa-youtube"></i></a></li>
								
							</ul>
							</div>
						</aside>
					</div>
				</div>
			</div><!-- Container /- -->
			<!-- Bottom Footer -->
			<div class="container-fluid no-padding bottom-footer">
				<p>&copy; 2023 Dental Care & Cure. All Rights Reserved.</p>
			</div><!-- Bottom Footer /- -->
		</footer><!-- Footer /- -->
		
	</div><!-- Main Container -->
	<!-- JQuery v1.11.3 -->
	<script src="js/jquery.min.js"></script>

	<!-- Library - Modernizer -->
	<script src="libraries/modernizr/modernizr.js"></script>
	
	<!-- Library - Bootstrap v3.3.5 -->
	<script src="libraries/bootstrap/bootstrap.min.js"></script><!-- Bootstrap JS File v3.3.5 -->

	<!-- jQuery Easing v1.3 -->
	<script src="js/jquery.easing.min.js"></script>

	<!-- Library - jQuery.appear -->
	<script src="libraries/appear/jquery.appear.js"></script>
	
	<!-- Library - OWL Carousel V.2.0 beta -->
	<script src="libraries/owl-carousel/owl.carousel.min.js"></script>
	
	<!-- jQuery For Number Counter -->
	<script src="libraries/number/jquery.animateNumber.min.js"></script>
	
	<!-- Library - Isotope Portfolio Filter -->
	<script src="libraries/isotope/isotope.pkgd.min.js"></script>
	
	<!-- Library - Magnific Popup - v1.0.0 -->
	<script src="libraries/magnific-popup/jquery.magnific-popup.min.js"></script>

	<!-- Library - Google Map API -->

	
	<!-- Library - Theme JS -->
	<script src="js/functions.js"></script>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WXFMHMFJ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
</body>


</html>