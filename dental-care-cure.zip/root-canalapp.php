﻿<?php
// ---- Page settings ----
// Ye app-view page hai (bina header/footer ke), isliye includes use nahi kiye
$pageCanon = "https://dentalcarencure.com/root-canalapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
	<link rel="canonical" href="<?= $pageCanon ?>"/>

<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container no-padding department-section">  <div class="we-are-best col-md-12 col-sm-12 no-padding">
    <div class="we-are-best-block">
      <div>
        <h3>Root Canals</h3>
        <p> <img src="images/TreatmentOptions.jpg" class="imgbdr" alt="Root Canal" title="Root Canal">Has your dentist told you that you need root canal treatment? If so, you're not alone. Millions of teeth are treated and saved each year with root canal, or endodontic treatment. <br>
          Inside the tooth, under the white enamel and a hard layer called the dentin, is a soft tissue called the pulp. The pulp contains blood vessels, nerves and connective tissue, and helps to grow the root of your tooth during development. In a fully developed tooth, the tooth can survive without the pulp because the tooth continues to be nourished by the tissues surrounding it.<br>
        </p>
        <p> Endodontic treatment treats the inside of the tooth. Endodontic treatment is necessary when the pulp becomes inflamed or infected. The inflammation or infection can have a variety of causes: deep decay, faulty crowns, or a crack or chip in the tooth. In addition, trauma to a tooth may cause pulp damage even if the tooth has no visible chips or cracks. If pulp inflammation or infection is left untreated, it can cause pain or lead to an abscess. </p>
        <br>
        <br>
        <h3>How does endodontic treatment save the tooth?</h3>
        <p> <img src="images/root-canal-treatment.jpg" class="imgbdr" alt="Root Canal" title="Root Canal"> During root canal treatment, the inflamed or infected pulp is removed and the inside of the tooth is carefully cleaned and disinfected, then filled and sealed with a rubber-like material called gutta- percha. Afterwards, the tooth is restored with a crown or filling for protection. After restoration, the tooth continues to function like any other tooth.
          Crown
          
          modern root canal treatment is very similar to having a routine filling and usually can be completed in one or two appointments, depending on the condition of your tooth and your personal circumstances. You can expect a comfortable experience during and after your appointment. </p>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h3>Saving the natural tooth with root canal treatment has many advantages:</h3>
        <ul>
          <li>Efficient chewing </li>
          <li>Normal biting force and sensation </li>
          <li>Natural appearance </li>
          <li>Protects other teeth from excessive wear or strain </li>
        </ul>
        <p>Endodontic treatment helps you maintain your natural smile, continue eating the foods you love and limits the need for ongoing dental work. With proper care, most teeth that have had root canal treatment can last as long as other natural teeth and often for a lifetime. </p>
      </div>
    </div>
  </div>
</div>
</body>
</html>