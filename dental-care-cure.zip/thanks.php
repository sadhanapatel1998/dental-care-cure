<?php
// ---- Page settings ----
$pageTitle = "Dental Care N Cure Clinic New Delhi- Thank You For Visit";
$pageDesc  = "Dentalcarencure offer best dental treatment in Paschim Vihar, New Delhi.";
$pageCanon = "https://dentalcarencure.com/thanks.php";
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en" class=""><!--<![endif]-->

<head>
	<meta charset="utf-8">
		<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
		<title><?php echo $pageTitle; ?></title>
		<meta name="description" content="<?php echo $pageDesc; ?>">
		<!-- <meta name="keywords" content="Thank you, Dental Care N Cure"> -->
		<!-- <meta name="googlebot" content="noodp" /> -->
		<meta name="robots" content="index, follow" />
		<!-- <meta name="robots" content="noodp" /> -->
		<meta name="distribution" content="Global" />
		<meta name="language" content="EN-US" />
		<meta name="classification" content="Helthcare" />
		<meta name="author" content="Dental Healthcare India " />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
	    <link rel="canonical" href="<?php echo $pageCanon; ?>"/>


		<script type="application/ld+json">
			{
			  "@context": "https://schema.org",
			  "@type": "MedicalOrganization",
			  "name": "Dental Care 'N' Cure",
			  "url": "https://dentalcarencure.com/",
			  "logo": "https://dentalcarencure.com/images/logo-banner.png",
			  "sameAs": [
				"https://www.facebook.com/DentalCarenCure/",
				"https://x.com/DentalCareNCure",
				"https://www.instagram.com/dentalcarencure/",
				"https://www.youtube.com/channel/UCIlqkg_bkS8_949GqFP74Xw"
			  ]
			}
			</script>
		

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-62932289-1', 'auto');
  ga('send', 'pageview');








</script><practo:abs_widget widget="e0b38d457e7af9c3" class="onli_link"></practo:abs_widget><script src="https://www.practo.com/bundles/practopractoapp/js/abs_widget_helper.js"></script>
<!-- <meta name="yandex-verification" content="3c790e16192cb4c9" /> -->


	<!-- Standard Favicon -->
	<link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
	
	<!-- For iPhone 4 Retina display: -->
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">
	
	<!-- For iPad: -->
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">
	
	<!-- For iPhone: -->
	<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">	
	
	<!-- Library - Loader CSS -->
	<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

	<!-- Library - Google Font Familys -->

	<!-- Library - Bootstrap v3.3.5 -->
    <link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">
	
	<!-- Font Icons -->
	<link rel="stylesheet" type="text/css" href="libraries/fonts/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

	<!-- Library - OWL Carousel V.2.0 beta -->
	<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

	<!-- Library - Animate CSS -->
	<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

	<!-- Library - Magnific Popup -->
	<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

	<!-- Custom - Common CSS -->
	<link rel="stylesheet" type="text/css" href="css/plugins.css">
	<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">

	<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->
	
	<!-- Custom - Theme CSS -->
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
    <style type="text/css">
    .footer {
    float: left;
    margin-top: 20px;
    margin: 0 0 0 15px;
    text-align: center;
    width: 97%;
}
    </style>
	<!--[if lt IE 9]>
		<script src="js/html5/respond.min.js"></script>
    <![endif]-->

</head><body data-offset="200" data-spy="scroll" data-target=".ow-navigation">
	<!-- Loader -->
	<!-- Loader /- -->
	
	<a id="top"></a>
	<!-- Main Container -->
	<div class="main-container">
		<!-- Header -->
		<header class="header-main" style="border-bottom: 2px solid #ccc;">
			<!-- Top Header -->
			<div class="top-header container-fluid no-padding">
				<!-- Container -->
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<p>We take care of your smiles</p>
						</div>
						<div class="col-md-6 text-right">
							<ul>
								<li><a href="https://www.facebook.com/DentalCarenCure/" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>	
								<li><a href="https://twitter.com/DentalCareNCure" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://www.instagram.com/dentalcarencure/" target="_blank" title="Instagram"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCIlqkg_bkS8_949GqFP74Xw" target="_blank"  title="youtube"><i class="fa fa-youtube"></i></a></li>
							</ul>
							
						</div>
					</div>
				</div><!-- container /- -->
			</div><!-- Top Header /- -->
			<!-- Logo Block -->
			<div class="middle-header container-fluid no-padding">
				<!-- Container -->
				<div class="container">
					<div class="row">
						<div class="col-md-3 logo-block pull-left">
							<a href="index.php" title="Logo"><img src="images/logo.png" class="phlogo" alt="Logo" style="width: 180px;
    margin-top: 5px;" /></a>
						</div>
						<div class="col-md-9"><div class="location">
								<h3><img src="images/location-ic.png" alt="Location" /> Our Location</h3>
								<p>1st Floor, A3/15, Main Road, Paschim Vihar, New Delhi - 110063</p>
							</div>
							<div class="phone">
								<h3><img src="images/phone-ic.png" alt="phone" />+91- 9310999214</h3>
								<p>Call for free consultation</p>
							</div>
						</div>
					</div>
				</div><!-- Container -->
			</div><!-- Logo Block /- -->
			<!-- Navigation -->
			
		</header>

		<!-- Page Banner -->
		<!-- Page Banner /- -->
		
		<!-- Container -->
		<!-- Container /- -->
		
		<!-- Map Section -->
		<!--  Map Section /- -->
		
		<!-- Container -->
		<div class="container company_pro" style="margin-top:3%;">

			<div class="col-lg-12 text-left">
					<h2> <b>Thank You</b></h2>
				<p>
					<b>Dear Valuable Guest,
                    <br>
Greetings from Dental Care 'N' Cure !                    
                    </b> 

				</p>
				<p style="width:665px; font-family: initial;">
					We have successfully received your appointment details. Our team of appointment experts will get back to you

shortly with best information received from your email.<br>
<br>
In the meanwhile, should you need any quick clarification, please feel free to contact us at <br>

<a href="mailto:drmansiarora@gmail.com" style=" color:blue"> drmansiarora@gmail.com</a> or + 91- 9310999214.<br>

<br>

&nbsp;
<br>
 <b> &nbsp; Best Regards, 
                <br>
&nbsp;

Guest Relationship Team</b>


				</p>

               
			</div>

		</div><!-- Container /- -->
	
		<div class="footer">
			

			

			<div class="col-lg-12 copy-right">
				<p>
					  <a href="http://www.dentalcarencure.com/" target="_blank" style="    background: none repeat scroll 0 0 #ee3c04;
    border: 1px solid #ec3804;
    color: #FFF;
    padding: 8px 50px">Visit Again</a>
				</p>
			</div>

		</div><!-- Footer -->
		<!-- Footer /- -->
		
	</div>

</body>


</html>