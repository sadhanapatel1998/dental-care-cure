﻿<?php
// ---- Page settings ----
$pageCanon = "https://dentalcarencure.com/teeth-whiteningapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
    <link rel="canonical" href="<?php echo $pageCanon; ?>" />

<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container-fluid no-padding department-section">  <div class="we-are-best col-md-12 col-sm-12 no-padding">
    <div class="we-are-best-block">
      <div>
        <h3>Teeth Whitening</h3>
        <p> tooth whitening lightens teeth and helps to remove stains and discoloration. Whitening is among the most popular cosmetic dental procedures because it can greatly improve how your teeth look. <br>
          Whitening is not a one-time procedure. It will need to be repeated from time to time if you want to maintain the brighter color. <br>
        </p>
        <strong>What It's Used For</strong>
        <p> The outer layer of a tooth is called the enamel. The color of natural teeth is created by the reflection and scattering of light off the enamel, combined with the color of the dentin under it. Your genes affect the thickness and smoothness of the enamel. Thinner enamel allows more of the color of the dentin to show through. Having smoother or rougher enamel also affects the reflection of light and therefore the color. </p>
        <p> Every day, a thin coating (pellicle) forms on the enamel and picks up stains. Tooth enamel also contains pores that can hold stains. </p>
        <strong style="font-style:italic;">The most common reasons for teeth to get yellow or stained are:</strong>
        <ul style="padding-left:20px;">
          <li>Using tobacco </li>
          <li>Drinking dark-colored liquids such as coffee, cola, tea and red wine </li>
          <li>Not taking good care of your teeth </li>
        </ul>
        <p> Aging makes teeth less bright as the enamel gets thinner and the dentin becomes darker.</p>
        <p>It is also possible to have stains inside the tooth. These are called intrinsic stains. For example, intrinsic stains can be caused by exposure to too much fluoride as a child while teeth are developing. Other causes include tetracycline antibiotics.</p>
        <p>Trauma may also darken a tooth.</p>
        <p>Tooth whitening is most effective on surface (extrinsic) stains.</p>
      </div>
    </div>
  </div>
</div>
</body>
</html>