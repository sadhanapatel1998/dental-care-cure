﻿<?php
// ---- Page settings ----
$pageCanon = "https://dentalcarencure.com/smile-designapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
  <link rel="canonical" href="<?php echo $pageCanon; ?>" />

<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container-fluid no-padding department-section">  <div class="we-are-best col-md-12 col-sm-12 no-padding">
    <div class="we-are-best-block">
      <div>
        <h3 class="fontadj">Smile Design <span style="font-style:italic;">SMILE MAKEOVER</span> (SDSM)</h3>
        <strong style="font-size:18px;"> High Quality Cost Effective Treatment </strong> <br>
        <div class="col-md-7 col-sm-7 col-xs-7 smiledesigning">
          <p> Cosmetic solutions by Dr. Mansi Arora Punia.  A Smile Makeover gives you the opportunity improve your appearance, boost your self-confidence and improve your quality of life. If you tend to hide your mouth or cover your smile because you're embarrassed about the appearance of your teeth, consider a fresh smile as a way of improving yourself and smile without hesitation. </p>
          <strong>But what does smile design actually mean?</strong>
          <p> In the everyday language, the term ‘smile design’ is often used as the synonym of a dental treatment with esthetic purposes. </p>
          <p> However, smile design is actually a process before the treatment starts: Smile design is the planning and pre-visualization of the desired end result of an esthetic dental treatment targeting a more harmonious state instead of the current disharmony, according to the rules of facial, smile, tooth and gingival harmony and the individual needs of the patient, paying particular attention to the functional aspects and the feasibility. </p>
          <ul class="listn">
            <li> <strong>Why SDSM </strong> </li>
            <p> -- If You Have Yellow Teeth <br>
              --Size Of Teeth Too Small (By Birth/Or Generally In Case     Of Nonvegetarians Middle Age People) <br>
              --Malformed/Crooked/Uneven Teeth/Non Aligned Teeth 
              (Since Childhood Or In Adults After Extraction Of One Or More Teeth) <br>
              --Unable To Close Lips Due To Front Teeth Out <br>
              -- Wrinkles Around The Mouth <br>
            </p>
            <li><strong>Who Should go for SDSM</strong></li>
            <p> --   All Age Groups</p>
            <li><strong>What are Advantage of SDSM</strong> </li>
            <p> --Boost Confidence; Appearance; Smile And Personality <br>
              -- Youthful Appearance Of Face <br>
            </p>
            <li> <strong>What Cost of SDSM</strong> </li>
            <p>--Always Customized And Depends Upon Number Of Teeth And The Treatment Procedure Required.</p>
          </ul>
          <p> Dentistry is no longer just a case of filling and taking out teeth. Nowadays many people turn to cosmetic dentistry, or ‘aesthetic dentistry', as a way of improving their appearance. They do this in the same way they might use cosmetic surgery or even a new hairstyle. The treatments can be used to straighten, lighten, reshape and repair teeth. Cosmetic treatments include veneers, crowns, bridges, tooth-coloured fillings, Dental Implant and Teeth Whitening.</p>
        </div>
        <div class="col-md-5 col-sm-5 col-xs-5 smiledesigning"> <img src="images/Smile-designing.jpg" alt="Smile Design" title="Smile Design" style="width:100%;"> <img src="images/smile-design-protocol.jpg" width="100%"> </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>