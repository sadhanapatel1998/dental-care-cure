﻿<?php
// ---- Page settings ----
// Ye app-view page hai (bina header/footer ke), isliye includes use nahi kiye
$pageCanon = "https://dentalcarencure.com/dental-crownsapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
		<link rel="canonical" href="<?= $pageCanon ?>"/>

<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container no-padding department-section">  <div class="we-are-best col-md-12 col-sm-12 no-padding">
    <div class="we-are-best-block">
      <div>
        <h3 class="fontadj">Dental Crowns and Tooth Bridges</h3>
        <p> <img src="images/dental-crowns.jpg" class="imgbdr" alt="Dental Crown" title="Dental Crown" style="float: right;
    width: 300px;
    margin-left: 25px;"><strong>What are Dental Crowns and Bridges?</strong><br>
          Crowns and bridges are fixed prosthetic devices. Unlike removable devices such as dentures, which you can take out and clean daily, crowns and bridges are cemented onto existing teeth or implants, and can only be removed by a dentist. </p>
        <p><strong>How do Crowns Work?</strong><br>
          A crown is used to entirely cover or "cap" a damaged tooth. Besides strengthening a damaged tooth, a crown can be used to improve its appearance, shape or alignment. A crown is placed on top of an implant to provide a tooth-like shape and structure for function. Porcelain or ceramic crowns can be matched to the color of your natural teeth.<br>
          <span style="font-style:italic;">Your dentist may recommend a crown to:</span> </p>
        <ul class="listitem">
          <li> Replace a large filling when there isn't enough tooth remaining </li>
          <li> Protect a weak tooth from fracturing </li>
          <li> Restore a fractured tooth </li>
          <li> Attach a bridge </li>
          <li> Cover a dental implant</li>
          <li> Cover a discolored or poorly shaped tooth </li>
          <li> Cover a tooth that has had root canal treatment </li>
        </ul>
        <strong>How do Bridges Work?</strong><br>
        A bridge may be recommended if you're missing one or more teeth. Gaps left by missing teeth eventually cause the remaining teeth to rotate or shift into the empty spaces, resulting in a bad bite. The imbalance caused by missing teeth can also lead to gum disease and temporomandibular joint (TMJ) disorders. 
        
        Bridges are commonly used to replace one or more missing teeth. They span the space where the teeth are missing. Bridges are cemented to the natural teeth or implants surrounding the empty space. These teeth, called abutments, serve as anchors for the bridge. A replacement tooth, called a pontic, is attached to the crowns that cover the abutments. As with crowns, you have a choice of materials for bridges. Your dentist can help you decide which to use, based on the location of the missing tooth (or teeth), its function, aesthetic considerations and cost. <br>
      </div>
    </div>
  </div>
</div>
</body>
</html>