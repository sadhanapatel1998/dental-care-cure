﻿<?php
// ---- Page settings ----
$pageCanon = "https://dentalcarencure.com/cosmetic-dentistryapp.html";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114-precomposed.png">

<!-- For iPad: -->
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72-precomposed.png">

<!-- For iPhone: -->
<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57x57-precomposed.png">

<!-- Library - Loader CSS -->
<link rel="stylesheet" type="text/css" href="libraries/loader/loaders.min.css">

<!-- Library - Google Font Familys -->

<!-- Library - Bootstrap v3.3.5 -->
<link rel="stylesheet" type="text/css" href="libraries/bootstrap/bootstrap.min.css">

<!-- Font Icons -->
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="libraries/fonts/elegant-icons.css">

<!-- Library - OWL Carousel V.2.0 beta -->
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="libraries/owl-carousel/owl.theme.css">

<!-- Library - Animate CSS -->
<link rel="stylesheet" type="text/css" href="libraries/animate/animate.min.css">

<!-- Library - Magnific Popup -->
<link rel="stylesheet" type="text/css" href="libraries/magnific-popup/magnific-popup.css">

<!-- Custom - Common CSS -->
<link rel="stylesheet" type="text/css" href="css/plugins.css">
<link rel="stylesheet" type="text/css" href="css/navigation-menu.css">
<link rel="canonical" href="<?php echo $pageCanon; ?>"/>
<!--[if IE]>
		<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
	<![endif]-->

<!-- Custom - Theme CSS -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css">
<style>
.fontadj {
	font-size: 18px;
	font-weight: 600;
}
</style>

</head><body><div class="container no-padding department-section">  <div class="we-are-best col-md-8 col-sm-8" style="padding-bottom:10px;">
    <div>
      <h2 class="fontadj"> What is meant by Cosmetic Dentistry</h2>
      <p> Cosmetic dentistry includes all procedures of dentistry that are aimed at creating a positive change to your teeth and smile.&nbsp;Cosmetic dentistry procedures have to be in compliance with the overall general and oral health of the patient.&nbsp; Your smile creates an immediate, subconscious, visual impact on people you meet. A brighter smile gives the impression of youth, vitality, radiant health, happiness, and warmth. A bright smile is perceived as a healthy smile </p>
      <h2 class="fontadj"> Cosmetic Procedures </h2>
      <p> Smile makeovers can have dramatic results on your overall facial appearance; it helps to boost your confidence, self-esteem, and make you want to smile more. With modern advances in dentistry, cosmetic dentistry procedures can range from teeth whitening to change in shape and size of teeth. All these cosmetic dentistry procedures give a complete smile makeover and beautify the face on the whole. </p>
      <h3>Procedures in Cosmetic Dentistry/Smile Makeovers</h3>
      <h4>Composite Veneers</h4>
      <p>Composite Bonding/composite veneers are a good option because it provides a successful attachment between the filling material and the tooth’s original enamel and dentin. </p>
      <ul class="listitem">
        <li> Looks like the original tooth and functions like it as well. </li>
        <li> Used to recreate a smile in an additive manner, with little or no tooth reduction </li>
        <li> Direct composite bonding, in the hands of a skilled operator, is less costly than porcelain veneers and crowns and can be long-lasting with proper maintenance. </li>
      </ul>
      <h4> Who all can benefit from Veneers- </h4>
      <ul class="listitem">
        <li> Repair Broken or Chipped Teeth </li>
        <li> Discolored Teeth </li>
        <li> To change shape of Crooked Teeth </li>
        <li> To change size of teeth. If someone has very small odd looking tooth. </li>
      </ul>
      <h4> Porcelain Veneers </h4>
      <p>Porcelain veneers are thin pieces of porcelain used to recreate the natural look of teeth. Porcelain veneers provide strength and resilience comparable to natural tooth enamel.</p>
      <strong>Benefits-</strong> <br>
      <ul class="listitem">
        <li> Material of choice for those looking to make slight position alterations, </li>
        <li> Efficient to change tooth shape, size, and/or color. </li>
      </ul>
    </div>
  </div>
  <div class="col-md-4 col-sm-4"> <img src="images/which-cosmetic-dentistry.png" alt="Cosmetic Dentistry" title="Cosmetic Dentistry"></div>
  <div class="we-are-best col-md-12 col-sm-12" style="padding-bottom:10px;">
    <div>
      <h4> Minimal Prep or “No-Prep” Veneers </h4>
      <p>Some patients are looking for an alternative to traditional dental veneers or bonding, but be aware that this treatment option is not appropriate for everyone.
        Just as with porcelain veneers, “no-prep” or minimal preparation veneers— so called because they typically don’t require the dentist to remove as much tooth material—are bonded to the front surface of your teeth. Often, the placement of no-prep veneers can be done more quickly and with less discomfort than traditional veneers.
        No prep veneers can be performed composite veneers called by name of Componeers to fit to existing tooth structure or can be custom made porcelain veneers. </p>
      <br>
    </div>
  </div>
  <div class="we-are-best col-md-8 col-sm-8">
    <div>
      <h4> Crowns </h4>
      <strong>Use of Crowns</strong>
      <ul class="listitem">
        <li>Recreating the form and function of a damaged tooth, because a crown basically replaces the entire external portion of the tooth. </li>
        <li> Crowns are not limited to simply replacing the original tooth, but can be designed to create an even better esthetic appearance. </li>
      </ul>
      <strong>Types of crowns-</strong> <br>
      1. Porcelain fused to metal <br>
      2. Metal free zirconiz crowns <br>
      3. Metal free emax crowns <br>
      <br>
      <h4> Orthodontics and Aligners </h4>
      <p>Orthodontics is more commonly referred to as “braces,” but this simple term can be misleading, as the science of orthodontics is actually quite precise. <br>
        <br>
        <strong>Use of braces /aligners in cosmetic dentistry or smile makeover</strong> </p>
      <ul class="listitem">
        <li> Aligning the teeth to achieve a favorable position. </li>
        <li> Closure of unwanted spaces between teeth </li>
        <li> Move the teeth that are too forwardly placed back, to achieve better lip closure and esthetics. </li>
        <li> Correct deep bites </li>
      </ul>
      <strong>Cosmetic Options in Braces-</strong> <br>
      <ul class="listitem">
        <li> Conventional Braces (Metallic) </li>
        <li> Ceramic Braces </li>
        <li> Lingual braces </li>
        <li> “Invisible Braces” (clear orthodontic aligners)
          <ul class="listitem">
            <li> Invisaligns </li>
            <li> Clearpath aligners </li>
            <li> K liners </li>
          </ul>
        </li>
      </ul>
      <p> Each option offers its own benefits and issues and should be carefully selected to suit the situation. </p>
      <br>
    </div>
  </div>
  <div class="we-are-best col-md-4 col-sm-4"> <img src="images/dental-crown2.jpg" title="Dental Crown" alt="Dental Crown"></div>
  <div class="we-are-best col-md-12 col-sm-12">
    <div>
      <h4 class="fontadj"> Periodontal Plastic Surgery/Gum surgeries </h4>
      <ul class="listitem">
        <li> Gummy smile-Some people have a very gummy smile and are unhappy with their appearance though the teeth seem to be fine. This can be corrected by simple gum surgeries. </li>
        <li> Dark/pigmented gums- gum surgeries can help one get pink gums if you have complain of dark gums. </li>
      </ul>
      <p>The real long-term goal of any periodontal surgery is to increase the life expectancy of the teeth and their usefulness; it is not a cure for periodontal disease. Basically, periodontal surgery removes tissue that has been transformed by the disease and then reconstructs the gums and surrounding tissues to better support the teeth and to recreate a normal appearance. </p>
      <br>
      <h4> Teeth Whitening </h4>
      <p>Teeth whitening commonly known as bleaching of teeth. Most teeth can be whitened and there are a number of ways to whiten teeth. </p>
      <strong>Types of teeth whitening-</strong> <br>
      <p> External tooth whitening- when vital teeth are bleached by direct contact with a safe and commonly used whitening agent, either in a dental office or at home. </p>
      <ul class="listitem">
        <li> Internal tooth whitening- single tooth which is root canal treated and discolored is bleached by placing a suitable agent in the pulp chamber. </li>
        <li> Office bleach- here teeth whitening is done by a dentist in the dental office. Ore effective </li>
        <li> Home bleach- bleaching agent is given to patient to apply on teeth. </li>
        <li> Teeth whitening remain one of the most economical ways to enhance your smile. </li>
      </ul>
      <h4> Tooth-Colored Fillings </h4>
      <p> Dentists no longer need to rely on unsightly metals to replace tooth structure lost to decay, but use high density, state-of-the-art plastic (composite resins) and porcelain materials instead. These materials more naturally mimic the look, feel, and function of natural teeth and actually bond directly to the remaining enamel and dentin. This means that new fillings preserve more of the natural tooth so less repair work is necessary immediately and in the future. These modern filling materials are also more natural in appearance; it’s almost impossible to tell that your tooth has a filling. And the past, teeth were filled with a mixture—or amalgam—of different metals. Today that is changing as more natural-looking and metal-free dental fillings are becoming the preferred approach. </p>
      <p>Dentists are using more tooth-like materials (composite resins and porcelains) that are both safe and predictable. The most important feature,&nbsp;for many people, is that they look and react more like natural teeth. </p>
      <br>
      <h4> Cosmetic Inlays and Onlays </h4>
      <p>Inlays and Onlays are indirect restorations that can be used to help an otherwise healthy tooth with a large filling. Inlays are placed within the grooves between the cusps (points) of a tooth, whereas Onlays are placed within the grooves and over the cusp tips. Inlays and Onlays can be uses replace old filings, more esthetically pleasing because they can be made to match a tooth’s natural color. Highly strengthen the structure of a tooth because of their durability and longevity.</p>
    </div>
  </div>
</div>
</body>
</html>